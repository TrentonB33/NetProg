Names:  Trenton Baldrey and Aaron Brooks

Platform developed on: Ubuntu 14.4 and 16.4

Difficulties:  C pointers are a bitch. We had some difficulty remembering how to manage memory.
Other than that, we had difficulties understanding which items needed to be converted to host byte order and back to network byte order.
We also had difficulties firguring out how to get and set the TIDs for transfer, but we resolved that.
Other than that, it took some time to get an understanding of how TCP needed to work.

Time spent on the assignment: 
Aaron: 12.5 Hours
Trenton: 11 Hours

Other: N/A




